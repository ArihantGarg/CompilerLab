I am using Make to shorten command to execute lex files.

## Running the Makefile

To build and run the project, use:
```sh
make run
```

Ensure make is installed