#include <bits/stdc++.h>
using namespace std;

set<char> ntSet; // nonTerminals -> ntSet
vector<pair<string, vector<vector<string>>>> cfg; // contextFreeGrammar -> cfg

string genNT() { // nonTerminalGenerator -> genNT
    string s = {*ntSet.begin()};
    s += "'";
    ntSet.erase(ntSet.begin());
    return s;
}

void parseProd(string s) { // parseProduction -> parseProd
    vector<vector<string>> rules;
    vector<string> temp;

    for(int i = 3; i < s.size(); i++) {
        if(s[i] == '|') {
            rules.push_back(temp);
            temp.clear();
        } else {
            temp.push_back({s[i]});
        }
    }
    if(!temp.empty())
        rules.push_back(temp);
    
    cfg.push_back({{s[0]}, rules});
}

void printCFG() {
    for(auto i : cfg) {
        cout << i.first << " -> ";
        for(int j = 0; j < i.second.size(); j++) {
            for(auto k : i.second[j]) {
                cout << k;
            }
            if(j != i.second.size() - 1)
                cout << "|";
        }
        cout << endl;
    }
}

void leftFactoring() { // equivalentLeftFactoredGrammar -> leftFactoring

    for(int z = 0; z < cfg.size(); z++) {
        vector<vector<string>> rhs = cfg[z].second;
        sort(rhs.begin(), rhs.end());

        vector<vector<string>> modRules; // modifiedRules -> modRules
        vector<vector<int>> grps; // groups -> grps

        int start = 0, sz = 1, prefix = 1; // startOfGroup -> start, sizeOfGroup -> sz, prefixLength -> prefix
        for(int j = 1; j < rhs.size(); j++) {
            if(rhs[j][0] == rhs[j-1][0]) {
                sz++;
            } else {
                grps.push_back({start, sz, prefix});
                start = j;
                sz = 1;
            }
        }
        grps.push_back({start, sz, prefix});

        for(int j = 0; j < grps.size(); j++) {

            int s = grps[j][0];
            int sz = grps[j][1];
            int pfx = grps[j][2];

            vector<string> pfxStr = {rhs[s][0]}; // prefixString -> pfxStr

            if(sz == 1) {
                modRules.push_back(rhs[s]);
            } else {
                while(1) {
                    bool match = true;
                    for(int k = s + 1; k <= s + sz - 1; k++) {
                        if(pfx >= rhs[k].size() || pfx >= rhs[k-1].size()) {
                            match = false;
                            break;
                        }
                        if(rhs[k][pfx] != rhs[k-1][pfx]) {
                            match = false;
                            break;
                        }
                    }
                    if(!match)
                        break;
                    
                    pfxStr.push_back(rhs[s][pfx]);
                    pfx++;
                }

                grps[j][2] = pfx;
                string newNT = genNT(); // nonTerminal -> newNT
                pfxStr.push_back(newNT);
                modRules.push_back(pfxStr);
                
                vector<vector<string>> newRules;
                for(int k = s; k <= s + sz - 1; k++) {
                    vector<string> tmp;
                    for(int l = pfx; l < rhs[k].size(); l++) {
                        tmp.push_back(rhs[k][l]);
                    }
                    newRules.push_back(tmp);
                }
                cfg.push_back({newNT, newRules});     
            }
        }   
        cfg[z].second = modRules;
    }
}

int main() {
    for(char ch = 'A'; ch <= 'Z'; ch++) {
        ntSet.insert(ch);
    }
    ifstream inFile("input.txt"); // inputFile -> inFile
    string num;
    getline(inFile, num);
    int n = stoi(num);
    fflush(stdin);
    string s;
    while(n--) {
        getline(inFile, s);
        parseProd(s);
    }  
    cout << "Input CFG - " << endl;
    printCFG();
    leftFactoring();
    cout << "Left Factored Grammar -  " << endl;
    printCFG();
}
