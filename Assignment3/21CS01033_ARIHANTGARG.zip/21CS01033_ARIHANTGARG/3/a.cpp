#include <iostream>
#include <cstring>

#define SUCCESS 1
#define FAILED 0

// Function prototypes
void E(), Edash(), T(), Tdash(), F();

const char *cursor;
char string[64];
bool isSuccess; // Global variable to track success

int main() {
    std::cout << "Enter the string: ";
    std::cin >> string; // Read input from the user
    cursor = string;
    isSuccess = true; // Initialize as true
    std::cout << "\nInput          Action\n";
    std::cout << "--------------------------------\n";

    // Call the starting non-terminal E
    E();
    if (isSuccess && *cursor == '\0') { // If parsing is successful and the cursor has reached the end
        std::cout << "--------------------------------\n";
        std::cout << "YES\n";
    } 
    else {
        std::cout << "--------------------------------\n";
        std::cout << "NO\n";
    }

    return 0;
}

// Grammar rule: E -> T E'
void E() {
    if (!isSuccess) return; // Early return if already failed
    std::cout << cursor << " E -> T E'\n";
    T(); // Call non-terminal T
    Edash(); // Call non-terminal E'
}

// Grammar rule: E' -> + T E' | $
void Edash() {
    if (!isSuccess) return; // Early return if already failed
    if (*cursor == '+') {
        std::cout << cursor << " E' -> + T E'\n";
        cursor++;
        T(); // Call non-terminal T
        Edash(); // Call non-terminal E'
    }
    else {
        std::cout << cursor << " E' -> $\n";
    }
}

// Grammar rule: T -> F T'
void T() {
    if (!isSuccess) return; // Early return if already failed
    std::cout << cursor << " T -> F T'\n";
    F(); // Call non-terminal F
    Tdash(); // Call non-terminal T'
}

// Grammar rule: T' -> * F T' | $
void Tdash() {
    if (!isSuccess) return; // Early return if already failed
    if (*cursor == '*') {
        std::cout << cursor << " T' -> * F T'\n";
        cursor++;
        F(); // Call non-terminal F
        Tdash(); // Call non-terminal T'
    } 
    else {
        std::cout << cursor << " T' -> $\n";
    }
}

// Grammar rule: F -> ( E ) | i
void F() {
    if (!isSuccess) return; // Early return if already failed
    if (*cursor == '(') {
        std::cout << cursor << " F -> ( E )\n";
        cursor++;
        E(); // Call non-terminal E
        if (*cursor == ')') {
            cursor++;
        } 
        else {
            isSuccess = false; // Mark as failed
        }
    } 
    else if (*cursor == 'i') {
        std::cout << cursor << " F -> i\n";
        cursor++;
    } 
    else {
        isSuccess = false; // Mark as failed
    }
}
