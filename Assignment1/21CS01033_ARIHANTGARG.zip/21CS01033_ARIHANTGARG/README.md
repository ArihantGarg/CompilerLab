# Lexical Analyser

## How to Run

```
g++ lexicalAnalyser.cpp -o lexicalAnalyser
./lexicalAnalyser
```

Now enter the input string, and the program will return all tokens

Sample cases are provided in cases.txt file
