#include<bits/stdc++.h>
using namespace std;

void inputGrammar(string inputFileName,char &startSymbol,map<char,vector<string>> &productions)
{   
    ifstream fin(inputFileName);

    int numRules;
    fin>>numRules;

    for (int i = 0; i < numRules; ++i) {
        string line;
        getline(fin, line);

        stringstream ss(line);
        char nonTerminal;
        string arrow, production;
        
        ss >> nonTerminal >> arrow; // Read the non-terminal and the '->'
        if(i==0)
        {
            startSymbol=nonTerminal;
        }

        while (ss >> production) {
            if (production == "|") continue;
            productions[nonTerminal].push_back(production);
        }
    }
}

void outputGrammar(string outputFileName,char &startSymbol,map<char,vector<string>> &productions)
{
    ofstream fout(outputFileName);

    fout<<productions.size()<<"\n";

    for(auto &entry:productions)
    {
        if(entry.first==startSymbol) // Outputting start symbol production rules first
        {
            fout<<entry.first<<" -> ";
            for(auto &prod:entry.second)
            {
                fout<<prod;
                if(prod!=entry.second.back())
                {
                    fout<<" | ";
                }
            }

            fout<<"\n";
        }
    }

    for(auto &entry:productions)
    {
        if(entry.first!=startSymbol) // Outputting all other production rules
        {
            fout<<entry.first<<" -> ";
            for(auto &prod:entry.second)
            {
                fout<<prod;
                if(prod!=entry.second.back())
                {
                    fout<<" | ";
                }
            }

            fout<<"\n";
        }
    }
}