#include <iostream>
#include <fstream>
#include <unordered_map>
#include <vector>
#include <stack>
#include <string>
#include <sstream>
#include <set>

using namespace std;

// Helper function to split string by delimiter
vector<string> split(const string &str, char delimiter) {
    vector<string> tokens;
    stringstream ss(str);
    string token;
    while (getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }
    return tokens;
}

// Module 1: Construct the LL(1) parsing table
void constructParsingTable(unordered_map<string, unordered_map<string, string>> &parseTable) {
    ifstream grammarFile("GrammarLL.txt");
    ifstream firstFollowFile("First-Follow.txt");

    unordered_map<string, set<string>> firstSet;
    unordered_map<string, set<string>> followSet;

    // Read and populate the FIRST and FOLLOW sets
    string line;
    while (getline(firstFollowFile, line)) {
        if (line.find("FIRST") != string::npos) {
            auto parts = split(line, '=');
            string nonTerminal = split(parts[0], '(')[1].substr(0, 1);
            vector<string> firstTokens = split(parts[1], ',');
            for (auto &token : firstTokens) {
                firstSet[nonTerminal].insert(token);
            }
        } else if (line.find("FOLLOW") != string::npos) {
            auto parts = split(line, '=');
            string nonTerminal = split(parts[0], '(')[1].substr(0, 1);
            vector<string> followTokens = split(parts[1], ',');
            for (auto &token : followTokens) {
                followSet[nonTerminal].insert(token);
            }
        }
    }

    // Read grammar rules and construct the parse table
    while (getline(grammarFile, line)) {
        auto parts = split(line, '-');
        string left = parts[0];
        string right = split(parts[1], '>')[1];

        if (right != "ε") {
            vector<string> rightTokens = split(right, '|');
            for (auto &token : rightTokens) {
                if (isupper(token[0])) {  // Non-terminal
                    for (auto &f : firstSet[token]) {
                        parseTable[left][f] = right;
                    }
                } else {  // Terminal
                    parseTable[left][string(1, token[0])] = right;
                }
            }
        } else {
            for (auto &f : followSet[left]) {
                parseTable[left][f] = right;
            }
        }
    }

    grammarFile.close();
    firstFollowFile.close();
}

// Module 2: Parse the input sequence using the parse table
void parseInputSequence(const unordered_map<string, unordered_map<string, string>> &parseTable, const string &input) {
    stack<string> parsingStack;
    parsingStack.push("$");
    parsingStack.push("S");  // Assuming S is the start symbol

    int i = 0;
    string currentInput = string(1, input[i]);

    while (!parsingStack.empty()) {
        string top = parsingStack.top();
        parsingStack.pop();

        if (top == "$") {
            if (currentInput == "$") {
                cout << "Accepted" << endl;
                return;
            } else {
                cout << "Syntactic Error: Unexpected input" << endl;
                return;
            }
        }

        if (isupper(top[0])) {  // Non-terminal
            if (parseTable.at(top).find(currentInput) != parseTable.at(top).end()) {
                string production = parseTable.at(top).at(currentInput);
                cout << top << " -> " << production << endl;
                if (production != "ε") {
                    for (int j = production.length() - 1; j >= 0; --j) {
                        parsingStack.push(string(1, production[j]));
                    }
                }
            } else {
                cout << "Syntactic Error: No production rule for " << top << " with input " << currentInput << endl;
                return;
            }
        } else {  // Terminal
            if (top == currentInput) {
                ++i;
                currentInput = string(1, input[i]);
            } else {
                cout << "Lexical Error: Expected " << top << " but found " << currentInput << endl;
                return;
            }
        }
    }
}

int main() {
    unordered_map<string, unordered_map<string, string>> parseTable;

    // Step 1: Construct the LL(1) parsing table
    constructParsingTable(parseTable);

    // Step 2: Parse the input sequence
    string input;
    cout << "Enter input string to parse: ";
    cin >> input;
    input += "$";  // Append end marker

    parseInputSequence(parseTable, input);

    return 0;
}
